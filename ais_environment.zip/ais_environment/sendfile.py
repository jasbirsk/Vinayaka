'''

@author: ieb
'''
import serial
import sys
import time



def writeBytes(source, dest, wchannel, nbytes, linebuffer, rate, log):
    if linebuffer is None:
        return None
    while(len(linebuffer) < nbytes):
        l = source.readline()
        if len(l) == 0:
            nbytes = len(linebuffer)
            dest.write(chr(wchannel+ord('1')))
            dest.flush()
            dest.write(chr(nbytes))
            dest.flush()
            for c in linebuffer[:nbytes]:
                dest.write(c)
            dest.flush()
            log.write(chr(wchannel+ord('1')))
            log.write(chr(nbytes))
            for c in linebuffer[:nbytes]:
                log.write(c)
            print "Final Sent %s to %s : %s " % (nbytes,wchannel, linebuffer[:(nbytes)])
            return None
        
        #if l[-2:-2] != "\r\n":
        #    if l[-2:-1] == "\n\r":
        #        l = l[:-2] + "\r\n"
        #    elif l[-1:-1] == "\n":
        #        l = l[:-1] + "\r\n"
        #    elif l[-1:-1] == "\r":
        #        l = l + "\n"
        #    else:
        #        l = l + "\r\n"
        linebuffer = linebuffer + l
    dest.write(chr(wchannel+ord('1')))
    dest.flush()
    dest.write(chr(nbytes))
    dest.flush()
    for c in linebuffer[:nbytes]:
        dest.write(c)
    dest.flush()
    log.write(chr(wchannel+ord('1')))
    log.write(chr(nbytes))
    for c in linebuffer[:nbytes]:
        log.write(c)
    print "Sent %s to %s : %s " % (nbytes,wchannel, linebuffer[:(nbytes)])
    
    return linebuffer[nbytes:]

def lineBuffersEmpty(lb):
    for l in lb:
        if l is not None:
            return False
    return True

if __name__ == '__main__':
    source = sys.argv[1]
    dest = sys.argv[2]
    sactive = False
    if dest[:8] == "/dev/tty":
        sactive = True
        desth = serial.Serial(dest, 9600, timeout=1)
    else:
        desth = open(dest,"wb")
    if sactive:
        time.sleep(5)
    if sactive  > 0:
        print "<<< %s" % desth.readline();
        print "<<< %s" % desth.readline();
    print "Writing \n"
    with open(source,"rb") as sourceh:
        content = sourceh.read()
        for c in content:
            desth.write(c)
            desth.flush()
            time.sleep(0.01)
            if c == '\n':
                if sactive and desth.inWaiting() > 0:
                    print "<<< %s" % desth.readline();
    if sactive:
        for i in range(1,10):
            if sactive and desth.inWaiting() > 0:
                print "<<< %s" % desth.readline();
            time.sleep(1)
        
