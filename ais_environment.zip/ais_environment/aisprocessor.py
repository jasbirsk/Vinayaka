'''
Created on Nov 12, 2012

@author: ieb
'''
import re
import logging
from ais import AISUnpackingException, BitVector, aivdm_unpack, aivdm_decode,\
    postprocess, field_groups, lengths
import sys
import traceback
import time
import os
import csv
import json
from base import NMEATarget, NMEASource
import datetime
from os import path
from aisbox import SubTile


class AISParser(object):
    '''
    Parses an AIS message using ais.py from GPSD. Much of the code here is taken from that file
    and recast into a class.
    '''
    
    def __init__(self, skiperr=True, scaled=True):
        self.skiperr = skiperr
        self.scaled = scaled
        self.payloads = None
        self.raw = None
        self.well_formed = False
        self.lc = 0
        
    
    def _parseline(self, line):
        if self.payloads is None:
            self.payloads = {'A':'', 'B':''}
        if self.raw is None:
            self.raw = ''
        if not line:
            logging.error("Parser: Not a line")
            return (None,None,None)
        self.lc += 1
        self.raw += line
        line = line.strip()
        # Strip off USCG metadata 
        line = re.sub(r"(?<=\*[0-9A-F][0-9A-F]),.*", "", line)
        # Compute CRC-16 checksum
        packet = line[1:-3]    # Strip leading !, trailing * and CRC
        csum = 0
        crc = -1
        for c in packet:
            csum ^= ord(c)
        csum = "%02X" % csum
        # Ignore comments
        if not line.startswith("!"):
            logging.error("Parser: Not a data line")
            return (None,None,None)
        # Assemble fragments from single- and multi-line payloads
        fields = line.split(",")
        try:
            expect = fields[1]
            fragment = fields[2]
            channel = fields[4]
            if fragment == '1':
                self.payloads[channel] = ''
                self.well_formed = True
            self.payloads[channel] += fields[5]
            try:
                # This works because a mangled pad literal means
                # a malformed packet that will be caught by the CRC check. 
                pad = int(fields[6].split('*')[0])
            except ValueError:
                pad = 0
            crc = fields[6].split('*')[1].strip()
        except IndexError:
            if self.skiperr:
                logging.error("%d: malformed line: %s\n" % (self.lc, line.strip()))
                self.well_formed = False
            else:
                raise AISUnpackingException(self.lc, "checksum", crc)
        except KeyError:
            logging.error("Key Error with %s " % line)
        if csum != crc:
            if self.skiperr:
                logging.error("%d: bad checksum %s, expecting %s: %s\n" % (self.lc, `crc`, csum, line.strip()))
                self.well_formed = False
            else:
                raise AISUnpackingException(self.lc, "checksum", crc)
        if not self.well_formed:
            logging.error("Parser: Not well formed %s" % (self.raw))
            return (None,None,None)
        if fragment < expect:
            logging.info("Parser: Fragment %s %s %s on channel %s payload %s" % (fragment, expect, self.raw, channel, self.payloads[channel]))
            return (None,None,None)
        # Render assembled payload to packed bytes
        bits = BitVector()
        bits.from_sixbit(self.payloads[channel], pad)
        del(self.payloads[channel])
        
        r = self.raw
        self.raw = ''
        return (self.lc, r, bits)


    def parse_ais_messages(self, line):
        "Parse the message."
        self.values = {}
        (lc, raw, bits) = self._parseline(line)
        if raw is None:
            return (None, None, None)
        self.values['length'] = bits.bitlen
        # Without the following magic, we'd have a subtle problem near
        # certain variable-length messages: DSV reports would
        # sometimes have fewer fields than expected, because the
        # unpacker would never generate cooked tuples for the omitted
        # part of the message.  Presently a known issue for types 15
        # and 16 only.  (Would never affect variable-length messages in
        # which the last field type is 'string' or 'raw').
        bits.extend_to(168)
        # Magic recursive unpacking operation
        try:
            cooked = aivdm_unpack(lc, bits, 0, self.values, aivdm_decode)
            # We now have a list of tuples containing unpacked fields
            # Collect some field groups into ISO8601 format
            for (offset, template, label, legend, formatter) in field_groups:
                segment = cooked[offset:offset+len(template)]
                if map(lambda x: x[0], segment) == template:
                    group = formatter(*map(lambda x: x[1], segment))
                    group = (label, group, 'string', legend, None)
                    cooked = cooked[:offset]+[group]+cooked[offset+len(template):]
            # Apply the postprocessor stage
            cooked = postprocess(cooked)
            # Now apply custom formatting hooks.
            if self.scaled:
                for (i, (inst, value)) in enumerate(cooked):
                    if value == inst.oob:
                        cooked[i][1] = "n/a"
                    elif inst.formatter:
                        if type(inst.formatter) == type(()):
                            # Assumes 0 is the legend for the "undefined" value 
                            if value >= len(inst.formatter):
                                value = 0
                            cooked[i][1] = inst.formatter[value]
                        elif type(formatter) == type(lambda x: x):
                            cooked[i][1] = inst.formatter(value)
            expected = lengths.get(self.values['msgtype'], None)
            # Check length; has to be done after so we have the type field 
            bogon = False
            if expected is not None:
                if type(expected) == type(0):
                    expected_range = (expected, expected)
                else:
                    expected_range = expected
                actual = self.values['length']
                if not (actual >= expected_range[0] and actual <= expected_range[1]):
                    bogon = True
                    if self.skiperr:
                        logging.info("%d: type %d expected %s bits but saw %s: %s\n" % (lc, self.values['msgtype'], expected, actual, raw.strip().split()))
                    else:
                        raise AISUnpackingException(lc, "length", actual)
            # We're done, hand back a decoding
            self.values = {}
            return (raw, cooked, bogon)
        except KeyboardInterrupt:
            raise KeyboardInterrupt
        except GeneratorExit:
            raise GeneratorExit
        except AISUnpackingException, e:
            if self.skiperr:
                logging.error("%s: %s\n" % (`e`, raw.strip().split()))
            else:
                raise
        except:
            (exc_type, exc_value, exc_traceback) = sys.exc_info()
            logging.error("%d: Unknown exception: %s\n" % (lc, raw.strip().split()))
            if self.skiperr:
                pass
            else:
                raise exc_type, exc_value, exc_traceback
        logging.error("Parser: Parser failed ")
        return (None, None, None)
    
class AISFilter(AISParser, NMEASource, NMEATarget):
    
    
    def __init__(self, source, config):
        super(AISFilter, self).__init__(skiperr=True, scaled=True)
        source.add(self)
        self._source = source
        self._inrange = {}
        self._tile = SubTile(minlat=config[0]["lat"],
                             minlon=config[0]["lon"],
                             maxlat=config[1]["lat"],
                             maxlon=config[1]["lon"])
        pass
    
    def recieve(self, message):
        (raw, parsed, bogon) = self.parse_ais_messages(message)
        if raw is None:
            return
        if bogon:
            return
        lat = None
        lon = None
        mmsi = None
        for x in parsed:
            if x[0].name == "lat":
                lat = x[1]
            if x[0].name == "lon":
                lon = x[1]
            if x[0].name == "mmsi":
                mmsi = x[1]
                
        if lat is not None and lon is not None:
            if self._tile.inside(lat, lon):
                self._send(message)
                self._inrange[mmsi] = True
            elif mmsi in self._inrange:
                del(self._inrange[mmsi])
        elif mmsi is not None and mmsi in self._inrange:
            self._send(message)
            
            
    def start(self):
        self._source.start()
            
    
        
    
'''
Prints an AIS Message in log format, maintaining a list of seen ships in CSV files, and a list of 
current ships. Extends NMEATarget allowing this to be added to a source.
Extends a AISPartse to allow the messages to be parsed into a readable format.
'''
class AISPrinter(AISParser, NMEATarget):
    TLOG = ("mmsi","shipname","status","lat","lon","course","speed","shiptype","callsign","destination")
    
    def __init__(self, config):
        super(AISPrinter, self).__init__(skiperr=config['skiperr'] if "skiperr" in config else True, scaled=config['scaled'] if "scaled" in config else True)
        self.verbose = config['verbose'] if "verbose" in config else False
        self.json = config['logjsondata'] if "logjsondata" in config else False
        self.dsv = config['dsv'] if "dsv" in config else False
        self.histogram = config['histogram'] if "histogram" in config else False
        self.malformed = config['malformed'] if "malformed" in config else False
        self.dump = config['dump'] if "dump" in config else False
        self.with_history =  config['history'] if "history" in config else False
        self.frequencies = {}
        self.basepath = path.abspath(config['basepath'])
        self.running = True
        self.ships_json = path.join(self.basepath,"ships.json")
        self.history_csv = path.join(self.basepath,"history.csv")
        if not path.exists(path.dirname(self.ships_json)):
            os.makedirs(path.dirname(self.ships_json))
        if not path.exists(path.dirname(self.history_csv)):
            os.makedirs(path.dirname(self.history_csv))
        if os.path.exists(self.ships_json):
            f = open(self.ships_json)
            self.ships = json.load(f)
            f.close()
        else:
            self.ships = {}
        self.dumpt = time.time()
        if self.with_history:
            self.allrecords = open(self.history_csv,"a")
            self.allrecordscsv = csv.writer(self.allrecords)
            header = [ "time" ]
            header.extend(AISPrinter.TLOG)
            self.allrecordscsv.writerow(header)
            self.allrecords.flush()
        
    def close(self):
        self.allrecords.flush()
        self.allrecords.close()
        
        
    def _get_details(self, parsed):
        details = {}
        for (bf,v) in parsed:
            details[bf.name] = v
        return details
    
    def _add(self, a, b):
        try:
            return (a if a is not None else 0) + (b if b is not None else 0)
        except:
            return 0
                
    def _save_details(self, details):
        try:
            mmsi = details.get("mmsi")
            key = "%s" % mmsi
            if mmsi is not None:
                if key not in self.ships:
                    self.ships[key] = {}
                
                length = self._add(details.get("to_bow"), details.get("to_stern"))
                if length > 0:
                    details['loa'] = length
                    
                beam = self._add(details.get("to_port"), details.get("to_starbord"))
                if length > 0:
                    details['beam'] = beam
                details['_ts'] = long(time.time()*1000);
                self.ships[key].update(details)
                
                if self.dumpt < time.time():
                    self.dumpt = time.time() + 60
                    # this ensures that anything inside the ships dict does not 
                    # result in ships.json becoming corrupted
                    todump = {}
                    for (k,v) in self.ships.iteritems():
                        try:
                            kv = int(k)
                            todump["%s" % kv] = json.loads(json.dumps(v))
                        except:
                            pass
                    f = open("%s.n" % self.ships_json,"w")
                    json.dump(todump,f,indent=2)
                    f.close()
                    os.rename("%s.n" % self.ships_json, self.ships_json)
        except:
            logging.error(traceback.format_exc())
        
    def _append_history(self, details):
        mmsi = details.get("mmsi")
        if mmsi != "n/a":
            key = "%s" % mmsi
            shipinfo = self.ships.get(key) or {}
            f = None
            try:
                history_file = path.join(self.basepath,"%s.csv" % mmsi)
                if not os.path.exists(history_file):
                    f = open(history_file,"w")
                    cw = csv.writer(f)
                    header = [ "time" ]
                    header.extend(AISPrinter.TLOG)
                    cw.writerow(header)
                else:
                    f = open(history_file,"a")
                    cw = csv.writer(f)
                history = [ datetime.datetime.now().isoformat()]
                for h in AISPrinter.TLOG:
                    d = details.get(h) or shipinfo.get(h)
                    history.append(d)
                cw.writerow(history)
                self.allrecordscsv.writerow(history)
                self.allrecords.flush()
            except:
                logging.error(traceback.format_exc())
            finally:
                if f is not None:
                    f.close()
            
            
    def cluster_details(self, details):
        '''
        Aggegates the details and maintains some overall stats of location.
        lat and lon are floats
        lat goes from +90 to -90
        lon goes from +180 to -180
        If we split the globe into cells 10 by 10, then count the number of hits in each cell that will give us an idea of the distribution.
        '''
        pass
            

    
    def recieve(self, message):
        if self.running:
            try:
                (raw, parsed, bogon) = self.parse_ais_messages(message)
                if raw is None:
                    return
                msgtype = parsed[0][1]
                if self.verbose >= 1 or (bogon and self.malformed):
                    logging.error(raw)
                if not bogon:
                    details = self._get_details(parsed)
                    self.cluster_details(details)
                    self._save_details(details)
                    if self.with_history:
                        self._append_history(details)
                    
                                
                    if self.json:
                        logging.error( "{" + ",".join(map(lambda x: '"' + x[0].name + '":' + str(x[1]), parsed)) + "}" )
                    elif self.dsv:
                        logging.error( "|".join(map(lambda x: str(x[1]), parsed)))
                    elif self.histogram:
                        key = "%02d" % msgtype
                        self.frequencies[key] = self.frequencies.get(key, 0) + 1
                        if msgtype == 6 or msgtype == 8:
                            dac = 0; fid = 0
                            if msgtype == 8:
                                dac = parsed[3][1]
                                fid = parsed[4][1]
                            elif msgtype == 6:
                                dac = parsed[6][1]
                                fid = parsed[7][1]
                            key = "%02d_%04d_%02d" % (msgtype, dac, fid)
                            self.frequencies[key] = self.frequencies.get(key, 0) + 1
                    elif self.dump:
                        for (inst, value) in parsed:
                            logging.error( "%-25s: %s" % (inst.legend, value))
                        logging.error( "%%" )
            except:
                logging.error(traceback.format_exc())
                pass
