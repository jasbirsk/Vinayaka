/*jslint node: true */
"use strict";

/** 
 * This code runs on the server, recieving a NMEA stream of AIS data via the update method.
 * If connected to a real NMEA reciever over a serial line, just listen to the data event of the serial
 * reader and push the data recieved into the update method.
 * It will write json files containing ships and their tracks for everything recieved indexed by MMSI number.
 * Runs in Node.js, requires "aisdecoder" : "0.0.1", "geolib" : "1.3.5", and "underscore" : "", NPM modules.
 * 
 * License is Apache Software License 2.0
 * (c) Ian Boston 2014
 */

var EventEmitter = require('events').EventEmitter;
var util = require('util');
var _ = require('underscore');
var aisdecoder = require ('aisdecoder');
var geolib = require ('geolib');


var DEBUG = false;

if (!DEBUG) {
    util.debug = function(args) {
    };
}



function AISMFactory() {
    var factory = this;

    function AISModel(position, range) {
        this.decoder = new aisdecoder.AisDecoder();
        this.ships = {};
        this.messages = [];
        this.position = position || { lat : 51.925013, lon: 1.300260 };
        this.range = range || 50000;
    }

    util.inherits(AISModel, EventEmitter);


    AISModel.prototype.update_ship = function(aisobject) {
        if (this.ships[aisobject.mmsi] === undefined) {
            this.ships[aisobject.mmsi] = new AISShipModel(aisobject);
        } else {
            this.ships[aisobject.mmsi].update(aisobject);
        }
    }

    AISModel.prototype.inrange = function(aisobject) {
        var ship =  this.ships[aisobject.mmsi];
        if (ship === undefined || ship.info.lat === undefined || ship.info.lon === undefined) {
            return false;
        } 
        if ( geolib.isPointInCircle(
            { latitude: ship.info.lat, longitude: ship.info.lon},
            { latitude: this.position.lat, longitude: this.position.lon},
            this.range) ) {
            if (!ship.basestation) {
                util.log(JSON.stringify(ship));                
            }
            // 235039652 244060919 235018953 235018953 244700538
            return true;
        }
        return false;
    }

    AISModel.prototype.update = function(data) {
        var self = this;
        self.messages.push(data);
        var aisobject = self.decoder.decode(data)
        if (aisobject !== undefined) {
            if (aisobject.mmsi !== undefined) {
                self.update_ship(aisobject);
                if ( self.inrange(aisobject) ) {
                    // dump emit all messages prior to this one, as this one is 
                    // in range and the previous messages may be relevant.
                    // then clear the messages/
                    // AIS messages are spread over a number of lines.
                    // bunched togather.
                    self.messages.forEach(function(message, i, array) {
                        self.emit("data", message);
                    });                    
                }
                self.messages = [];
            } else {
                util.log("No mmsi "+JSON.stringify(aisobject));
            }
        }
    }

    AISModel.prototype.set_position = function(position) {
        this.position = position;
    }

    function AISShipModel(aisobject) {
        this.mmsi = aisobject.mmsi;
        this.basestation = false;
        this.unknown_message_count = 0;
        this.unknown_message_type = 0;
        this.not_implemented = 0;
        this.info = {};
        this.history = [];
        this.update(aisobject);
    }
    /**
     * Save current data in history if required
     */
    AISShipModel.prototype.save = function(positionUpdate) {
        if (positionUpdate) {
            this.history.push({ lat: this.info.lat, lon: this.info.lon, heading: this.info.heading, speed: this.info.speed });
        }
    }

    AISShipModel.prototype.update = function(aisobject) {
        var self = this;
        if (aisobject.type === 'PositionReportClassA') {
            self.info = _.extend(self.info, aisobject);
            self.save(true);
        } else if (aisobject.type === 'ClassBCSPositionReport') {
            // 29 Mar 08:24:52 - {"type":"ClassBCSPositionReport","mmsi":808663857,"repeat":0,
            // "lon":113.443885,"lat":23.090231666666668,"course":130.4,"heading":130,"speed":0.1,
            // "accuracy":true,"regional":3,"cs":true,"display":true,"dsc":false,"band":false,"msg22":false,
            // "raim":false,"radio":530291,"assigned":0,"second":63}
            self.info = _.extend(self.info, aisobject);
            self.save(true);

        } else if (aisobject.type === 'BaseStationReport') {
            // 29 Mar 08:29:27 - {"type":"BaseStationReport","mmsi":4132201,"repeat":0,
            // "lon":122.17332,"lat":30.810088333333333,"accuracy":false,"raim":false,"radio":83009,"epfd":7}
            self.info = _.extend(self.info, aisobject);
            self.basestation = true;
            self.save(true);


        } else if (aisobject.type === 'StaticAndVoyageRelatedData') {
            // 29 Mar 08:31:13 - {"type":"StaticAndVoyageRelatedData","mmsi":259216000,
            // "repeat":0,"imo":9344760,"callsign":"LIAT","shipname":"MASTRAFJORD","shiptype":60,
            // "destination":"ARSVAAGEN/MORTAVIKA ","ais_version":0,"to_bow":66,"to_stern":63,"to_port":10,
            // "to_starboard":9,"epfd":1,"draught":4.5,"dte":0}
            self.info = _.extend(self.info, aisobject);
            self.save(false);
        } else if (aisobject.type === 'UnknownMessageType') {
            self.unknown_message_count++;
            self.save(false);
        } else if (aisobject.type === 'ExtendedClassBCSPositionReport') {
            // 29 Mar 08:33:16 - {"type":"ExtendedClassBCSPositionReport","mmsi":413769914,"repeat":0,
            // "lon":121.49704,"lat":31.37528,"course":197.2,"speed":0.1,"accuracy":true,"regional":0,
            // "second":40,"shipname":"HAI XUN 1077","shiptype":55,"to_bow":7,"to_stern":10,"to_port":2,
            // "to_starboard":2,"epfd":1,"raim":false,"dte":1,"assigned":false}
            self.info = _.extend(self.info, aisobject);
            self.save(true);            
        } else if (aisobject.type === 'UTCAndDateResponse') {
            // 29 Mar 15:22:47 - {"type":"UTCAndDateResponse","mmsi":4132108,"repeat":0,
            // "lon":121.71751666666667,"lat":32.01835166666667,"accuracy":true,"raim":false,"radio":0,"epfd":7}
            self.info = _.extend(self.info, aisobject);
            self.save(false);            
        } else if (aisobject.type === 'Not implemented: Static Data Report') {
            self.not_implemented++;
        } else {
            util.log(JSON.stringify(aisobject));
            self.unknown_message_type++;

        }
        return self;

    }

    factory.AISModel = AISModel;
}


module.exports = new AISMFactory();