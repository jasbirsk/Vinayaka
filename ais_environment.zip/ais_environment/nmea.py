'''
Created on Nov 9, 2012

This is the main NMEA server for use when connected up to real hardware.

@author: ieb
'''
import logging
import sys
from nmeaserver import NMEAMux, NMEATcpHandler, ThreadedTCPServer
import json
from nmeahardware import NMEASerialReader, NMEAI2CReader, OutputDemux,\
    OutputFile
from aisprocessor import AISPrinter, AISFilter
from base import FileReader
from demo.boat import Boat
from demo.instruments import WindInstrument, DepthInstrument, SpeedInstrument,\
    CompassInstrument, GPSInstrument
import time
    
def addLogging(reader, config):
    if "box" in config:
        reader = AISFilter(reader, config['box'])
    if "logging" in config and config["logging"]["type"] == "ais":
        logging.error("Creating AIS Printer")    
        printer = AISPrinter(config['logging'])
        reader.add(printer)
    return reader



if __name__ == '__main__':
    

    
    if len(sys.argv) != 1:
        logging.error("You must provide a config file as the first argument");
    f = open(sys.argv[1])
    print "Loading Config %s " % sys.argv[1]
    config = json.load(f)
    f.close()


    logging.error("Starting Mux")
    demux = None
    output = None
    mux = None
    if "demux" in config:
        demux = OutputDemux(config["demux"])
    if "file" in config:
        output = OutputFile(config["file"])
    else:
        mux = NMEAMux()

    tostop = []
    if "boat" in config:
        boat = Boat(config['boat'])
    for listener in config["listeners"]:
        reader = None
        if listener['type'] == 'serial':
            reader = addLogging(NMEASerialReader(listener['port'],listener['speed']), listener)
        elif listener['type'] == 'i2c':
            reader = addLogging(NMEAI2CReader(listener['port'],listener['speed']), listener)
        elif listener['type'] == 'demo-file':
            reader = addLogging(FileReader(listener['file']), listener)
        elif listener['type'] == 'demo-wind':
            reader = WindInstrument(listener, boat)
        elif listener['type'] == 'demo-depth':
            reader = DepthInstrument(listener, boat)
        elif listener['type'] == 'demo-speed':
            reader = SpeedInstrument(listener, boat)
        elif listener['type'] == 'demo-compass':
            reader = CompassInstrument(listener, boat)
        elif listener['type'] == 'demo-gps':
            reader = GPSInstrument(listener, boat)
        if reader is not None:
            if demux is not None:
                reader.add(demux.get_channel_target(listener['channel']))
            elif output is not None:
                reader.add(output)
            else:
                reader.add(mux)
            reader.start()
            tostop.append(reader)

        
    try:
        if demux is not None:
            demux.run()
        elif output is not None:
            while True:
                time.sleep(10)

        else:
            NMEATcpHandler.source = mux
            # Create the server, binding to localhost on port 9999
            server = ThreadedTCPServer((config["server"]["host"], config["server"]["port"]), NMEATcpHandler)
            logging.error("Serving")
        
            # Activate the server; this will keep running until you
            # interrupt the program with Ctrl-C
            server.serve_forever()
    finally:
        if demux is not None:
            demux.close()
        for x in tostop:
            x.running = False
    logging.error("Done")
