'''
Reads ship files producing a lat lon map based on csv files containing history of each ships path.
Column 5 of the csv is latidude as a float going from -90 to +90
Column 6 of the csv is longigure as a float going from -180 to +180
python aisbox.py aislog/ 45 60 -10 10

'''
from os import path, listdir
import sys
import csv
import math
from copy import copy


class SubTile(object):
    '''
    A tile is a 2d space of interest, with max min co-ordinates containing cells and the space is split 
    into a regular grid. There are methods to determine if a point is inside the grid, which cell within the 
    grid the lower bound of each cell as 2 arrays and the coordinates of an enitre row.
    '''
    
    def __init__(self, nlong=100, nlat=100, maxlat=90.0, minlat=-90.0, maxlon=180.0, minlon=-180.0):
        '''
        Create a subtile
        :param nlong: the number of longitude tiles.
        :param nlat: the number of latitude tiles
        :param maxlat: the maximum latitude
        :param minlat: the minimum latitude
        :param maxlon: the maximim longitude
        :param minlon: the minimum longitude
        '''
        self.nlong = nlong
        self.nlat = nlat
        self.minlat = float(minlat)
        self.maxlat = float(maxlat)
        self.minlon = float(minlon)
        self.maxlon = float(maxlon)
        self.latcel = (self.maxlat-self.minlat)/float(self.nlat)
        self.loncel = (self.maxlon-self.minlon)/float(self.nlong)
        self._longcells = self._fill(self.nlong,self.minlon, self.loncel)
        self._latcells = self._fill(self.nlat, self.minlat, self.latcel)
        
    def _fill(self, n, start, cellsize ):
        '''
        Fill an array with regulararly spaced values
        :param n: the number of elements
        :param start: value of the first element
        :param cellsize: increment of the value of each subsequent element
        '''
        l = [0] * n
        for i in range(n):
            l[i] = start+(cellsize*i)
        return l
    
    def size(self):
        '''
        Number of cells in a tile.
        '''
        return self.nlong*self.nlat
    
    def inside(self, lat, lon):    
        '''
        True if lat and lon are inside this subtile.
        :param lat:
        :param lon:
        '''
        return lat <= self.maxlat and lat > self.minlat and lon <= self.maxlon and lon > self.minlon
    
    def cell(self, lat, lon):
        '''
        the cell number of lat an lon, or None if lat and lon are not within the tile.
        :param lat:
        :param lon:
        '''
        if self.inside(lat, lon):
            latcel = int((lat-self.minlat)/self.latcel)
            loncel = int((lon-self.minlon)/self.loncel)
            return latcel*self.nlong+loncel
        return None
    
    def longcells(self, reversed=False):
        '''
        list of the lower value of each longitude cell
        :param reversed: reverse the list if true.
        '''
        if reversed:
            t = copy(self._longcells)
            t.reverse()
            return t
        return self._longcells
    
    def latcells(self, reversed=False):
        '''
        List of latitude cell lover values
        :param reversed: reverse the list if true
        '''
        if reversed:
            t = copy(self._latcells)
            t.reverse()
            return t
        return self._latcells
    
    def get_row(self, lat):
        '''
        Get a row of cells at the specified latitude
        :param lat:
        '''
        if self.inside(lat, self.maxlon):
            latcel = int((lat-self.minlat)/self.latcel)
            return (latcel*self.nlong,(latcel+1)*self.nlong)
        return (0,0)
        

class ClusterMap(object):
    '''
    A rectanculat map of cells
    '''
    
    def __init__(self, sub_tile, defcell=0):
        '''
        Create using a sub tile object
        :param sub_tile: the subtile object
        :param defcell: the default value of each cell.
        '''
        self.sub_tile = sub_tile
        self.cluster = [defcell] * sub_tile.size()
    
    def inc(self, lat, lon, by=1):
        '''
        Increment a cell at lat lon, assuming the cell is a numeric
        :param lat:
        :param lon:
        :param by:
        '''
        i = self.sub_tile.cell(lat, lon)
        if i is not None:
            self.cluster[i] += by
        else:
            print "Outside range %s %s " % (lat, lon)
                
    def get(self, lat, lon):
        '''
        Get the value at the cell at lat lon
        :param lat:
        :param lon:
        '''
        i = self.sub_tile.cell(lat, lon)
        if i is not None:
            return self.cluster[i]
        return None
    
    def get_row(self, latrow):
        '''
        Get the row at latitude latrow
        :param latrow:
        '''
        (start,end) = self.sub_tile.get_row(latrow)
        return self.cluster[start:end]


if __name__ == '__main__':

    location = sys.argv[1]
    
    sub_tile = SubTile(minlat=sys.argv[2], maxlat=sys.argv[3], minlon=sys.argv[4], maxlon=sys.argv[5])
    cluster_map = ClusterMap(sub_tile)
    final_map = ClusterMap(sub_tile)
        
    for historyfile in listdir(location):
        if historyfile[-3:] == 'csv':
            with open(path.join(location, historyfile)) as f:
                reader = csv.reader(f)
                headers = None
                line = 0
                lastlat = None
                lastlon = None
                for row in reader:
                    line += 1
                    if headers is None:
                        headers = row
                    else:
                        lat = row[4]
                        lon = row[5]
                        #print "%s %s" % (lat, lon)
                        try:
                            
                            lat = float(lat)
                            lon = float(lon)
                            if lat < -90 or lat > 90 or lon < -180 or lon > 180:
                                print "Bad Data %s %s %s:%s" % ( lat, lon, historyfile, line)
                            else:           
                                cluster_map.inc(lat, lon)
                                lastlat = lat
                                lastlon = lon
                        except IndexError:
                            print "ERROR: Index bad %s %s" % (lat, lon)
                        except ValueError:
                            pass
                if lastlat is not None and lastlon is not None:
                    final_map.inc(lat,lon)
                    
            
    writer = csv.writer(sys.stdout)
    writer.writerow(sub_tile.longcells())
    for latcell in sub_tile.latcells(reversed=True):
        row = cluster_map.get_row(latcell)
        row.insert(0,latcell)
        writer.writerow(row)
            
    writer = csv.writer(sys.stdout)
    writer.writerow(sub_tile.longcells())
    for latcell in sub_tile.latcells(reversed=True):
        row = final_map.get_row(latcell)
        row.insert(0,latcell)
        writer.writerow(row)
