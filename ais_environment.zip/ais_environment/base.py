'''
Created on Nov 14, 2012

@author: ieb
'''
import logging
import threading

'''
A NMEATartget is class that receives NMEA Sentences.
It must assume that the sentences may be recieved from multiple threads.
Recievers are in generall not threaded.
'''
class NMEATarget(object):
    def recieve(self, message):
        raise Exception("Please implement recieve method on %s " % self.__class__)

'''
A NMEASource is a source of NMEA messages. It provides methods to add and remove targets to which
Implementations can send messages. Messages are NMEA sentences.
Sources are in general threaded.
'''
class NMEASource(object):
    
    TO_KMH = 1.15077945
    TO_MPS = 0.514444444
    TO_FEET = 3.2808399

    
    def add(self, receiver):
        if not isinstance(receiver, NMEATarget):
            raise Exception("Only NMEATargets (%s) may be added to NMEASources (%) " % ( receiver.__class__, self.__class__))
        if not hasattr(self, "receivers2"):
            self.receivers2 = set()
        self.receivers2.add(receiver)
        self.receivers = frozenset(self.receivers2)
        logging.error("Added Client")
        return self
        
    def remove(self, receiver):
        if not hasattr(self, "receivers2"):
            self.receivers2 = set()
        self.receivers2.remove(receiver)
        self.receivers = frozenset(self.receivers2)
        logging.error("Removed Client")
        return self

    def _send(self, message):
        if not hasattr(self, "receivers"):
            return
        if message is None or len(message) == 0:
            return
        s = self.receivers
        for r in s:
            r.recieve(message)

    @staticmethod
    def addChecksum(packet):
        csum = 0
        for c in packet[1:]:
            csum ^= ord(c)
        return "%s*%02X" % (packet, csum)
    
'''
  i2C uses smbus python module that will read from teh i2C buss
  sudo apt-get install python-smbus.
  sudo apt-get install i2c-tools. 
'''
class FileReader(threading.Thread, NMEASource):
    def __init__(self, filename, *args, **kwargs):
        super(FileReader, self).__init__(*args, **kwargs)
        self.filename = filename
        self.running = True

    def _clean(self, op):
        if len(op) == 0:
            return op
        while( op[-1] == '\n' or op[-1] == '\r'):
            op = op[:-1]
        return op
    
    def run(self):
        if (self.running):
            with open(self.filename) as sourcef:
                logging.error("Reading %s " % self.filename)        
                while(self.running):
                    self._send(self._clean(sourcef.readline()))
            self.running = False
            logging.error("Closed %s " % self.filename) 

